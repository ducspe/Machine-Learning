import pandas as pd
import utils
from sklearn import svm
from sklearn.model_selection import train_test_split, GridSearchCV

import csv

dataset = pd.read_csv("train.csv")
utils.clean_data(dataset)
train, validation = train_test_split(dataset, test_size=0.7, shuffle=False)

feature_names = ["Pclass", "Age", "Fare", "Embarked", "Sex", "SibSp", "Parch"]


dataset_features = dataset[feature_names].values
dataset_target = dataset["Survived"].values

train_features = train[feature_names].values
train_target = train["Survived"].values

validation_features = validation[feature_names].values
validation_target = validation["Survived"].values

def svc_param_selection(X, y, nfolds):
    Cs = [10**4, 10**5, 10**6, 10**7, 10**8]
    gammas = [1e-8, 1e-7, 1e-7, 1e-6, 1e-5, 1e-4]
    kernel = ["rbf"]
    param_grid = {'kernel': kernel, 'C': Cs, 'gamma' : gammas}
    grid_search = GridSearchCV(svm.SVC(), param_grid, cv=nfolds)
    grid_search.fit(X, y)
    return grid_search.best_params_

#params = svc_param_selection(dataset_features, dataset_target, 10)
#print(params)

clf = svm.SVC(kernel='rbf', gamma=1e-7, C=10**7)

classifier_ = clf.fit(train_features, train_target)

print("Train Score: ", classifier_.score(train_features, train_target))

print("Validation Score: ", classifier_.score(validation_features, validation_target))


#########################################################################################################
test = pd.read_csv("test.csv")
utils.clean_data(test)
test_features = test[feature_names]
scores_list = classifier_.predict(test_features)

id=892
with open("output.csv", 'w', newline='') as resultfile:
    writer = csv.writer(resultfile, dialect='excel')
    writer.writerow(["PassengerId","Survived"])
    for val in scores_list:
        writer.writerow([id, val])
        id += 1


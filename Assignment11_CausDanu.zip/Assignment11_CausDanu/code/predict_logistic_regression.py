import pandas as pd
import utils
from sklearn import linear_model, preprocessing
from sklearn.model_selection import train_test_split

import csv

dataset = pd.read_csv("train.csv")
utils.clean_data(dataset)
train, validation = train_test_split(dataset, test_size=0.7, shuffle=False)

feature_names = ["Pclass", "Age", "Fare", "Embarked", "Sex", "SibSp", "Parch"]

dataset_features = dataset[feature_names].values
dataset_target = dataset["Survived"].values

train_features = train[feature_names].values
train_target = train["Survived"].values

validation_features = validation[feature_names].values
validation_target = validation["Survived"].values

clf = linear_model.LogisticRegression()
classifier_ = clf.fit(train_features, train_target)

print("Base case train score", classifier_.score(train_features, train_target))
print("Base case validation score", classifier_.score(validation_features, validation_target))

poly = preprocessing.PolynomialFeatures(degree=2)
poly_train_features = poly.fit_transform(train_features)
poly_validation_features = poly.fit_transform(validation_features)

classifier_ = clf.fit(poly_train_features, train_target)
print("Poly degree 2 train score: ", classifier_.score(poly_train_features, train_target))
print("Poly degree 2 validation score: ", classifier_.score(poly_validation_features, validation_target))

#########################################################################################################
test = pd.read_csv("test.csv")
utils.clean_data(test)
test_features = test[feature_names]
poly_test_features = poly.fit_transform(test_features)
scores_list = classifier_.predict(poly_test_features)

id=892
with open("output_second_submitted.csv", 'w', newline='') as resultfile:
    writer = csv.writer(resultfile, dialect='excel')
    writer.writerow(["PassengerId","Survived"])
    for val in scores_list:
        writer.writerow([id, val])
        id += 1

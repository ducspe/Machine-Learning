import pandas as pd
import utils
from sklearn import tree, model_selection
from sklearn.model_selection import train_test_split

import csv

dataset = pd.read_csv("train.csv")
utils.clean_data(dataset)
train, validation = train_test_split(dataset, test_size=0.7, shuffle=False)

feature_names = ["Pclass", "Age", "Fare", "Embarked", "Sex", "SibSp", "Parch"]

dataset_features = dataset[feature_names].values
dataset_target = dataset["Survived"].values

train_features = train[feature_names].values
train_target = train["Survived"].values

validation_features = validation[feature_names].values
validation_target = validation["Survived"].values


decision_tree = tree.DecisionTreeClassifier(random_state=1)
decision_tree_ = decision_tree.fit(train_features, train_target)

print("Base tree train score: ", decision_tree_.score(train_features, train_target))

scores = model_selection.cross_val_score(decision_tree_, train_features, train_target, scoring="accuracy", cv=50)
print("Base Tree all cross validation train scores: ", scores)
print("Base Tree train scores mean: ", scores.mean())

generalized_tree = tree.DecisionTreeClassifier(random_state=1, max_depth=7, min_samples_split=2)
generalized_tree_ = generalized_tree.fit(train_features, train_target)

print("Generalized Tree train score: ", generalized_tree_.score(train_features, train_target))

validation_scores = model_selection.cross_val_score(generalized_tree, validation_features, validation_target, scoring="accuracy", cv=50)
print("Generalized Tree all cross-validation validation scores: ", validation_scores)
print("Generalized Tree validation scores mean: ", validation_scores.mean())



#tree.export_graphviz(generalized_tree_, feature_names=feature_names, out_file="tree.dot")

#########################################################################################################
test = pd.read_csv("test.csv")
utils.clean_data(test)
test_features = test[feature_names]
scores_list = generalized_tree_.predict(test_features)

id=892
with open("output.csv", 'w', newline='') as resultfile:
    writer = csv.writer(resultfile, dialect='excel')
    writer.writerow(["PassengerId","Survived"])
    for val in scores_list:
        writer.writerow([id, val])
        id += 1

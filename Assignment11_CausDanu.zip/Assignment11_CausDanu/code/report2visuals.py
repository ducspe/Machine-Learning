
import matplotlib.pyplot as plt


scores = [0.775119, 0.775110, 0.76076]

labels = ["Decision Tree", "Logistic Regression", "SVM"]

plt.bar(labels, scores, color=["r","g","b"])
plt.ylabel("Test Score")
plt.xlabel("Algorithm")
plt.title("Algorithm Test Performance")
plt.show()
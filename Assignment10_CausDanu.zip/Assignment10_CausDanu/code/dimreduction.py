import pandas as pd
import utils
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

train = pd.read_csv("train.csv")

utils.clean_data(train)

feature_names = ["Pclass", "Age", "Fare", "Embarked", "Sex", "SibSp", "Parch"]

target = train["Survived"].values
features = train[feature_names].values

pca = PCA(n_components=7)
pca.fit(features, target)

print(pca)
print(pca.explained_variance_)
print(pca.singular_values_)

plt.bar(feature_names, pca.singular_values_)
plt.ylabel("Eigenvalue")
plt.xlabel("Features")
plt.show()
import pandas as pd
import utils
from sklearn.cluster import KMeans
from sklearn import preprocessing
import matplotlib.pyplot as plt

train = pd.read_csv("train.csv")

utils.clean_data(train)

feature_names = ["Pclass", "Age", "Fare", "Embarked", "Sex", "SibSp", "Parch"]

target = train["Survived"].values
features = train[feature_names].values

clf = KMeans(n_clusters=2, random_state=1).fit(features)

found = 0
for i in range(len(features)):
    new_prediction = features[i].astype(float)
    new_prediction = new_prediction.reshape(-1, len(new_prediction))
    prediction = clf.predict(new_prediction)
    if prediction[0] == target[i]:
        found += 1

accuracy = (found/len(features))*100
print("Kmeans clustering without scaling: ", accuracy)


X = preprocessing.scale(features)
clf.fit(X)
found = 0
for i in range(len(X)):
    new_prediction = X[i].astype(float)
    new_prediction = new_prediction.reshape(-1, len(new_prediction))
    prediction = clf.predict(new_prediction)
    if prediction[0] == target[i]:
        found += 1

accuracy = (found/len(X))*100
print("KMeans clustering with scaling: ", accuracy)


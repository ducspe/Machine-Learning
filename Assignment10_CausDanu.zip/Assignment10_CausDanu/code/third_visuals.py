import pandas as pd
import matplotlib.pyplot as plt
from utils import clean_data as clean

df = pd.read_csv("train.csv")

df = df.dropna()

plt.scatter(df.Embarked, df.Pclass)
plt.title("Class and Embarking place")
plt.xticks([0,1,2], ["Cherbourg", "Queenstown", "Southampton"])
plt.yticks([1,2,3], ["1st class", "2nd class", "3rd class"])
plt.xlabel("Embarking Place")
plt.ylabel("Class")

plt.show()

plt.scatter(df.Embarked, df.Age)
plt.title("Age and Embarking place")
plt.xticks([0,1,2], ["Cherbourg", "Queenstown", "Southampton"])
plt.xlabel("Embarking Place")
plt.ylabel("Age")

plt.show()
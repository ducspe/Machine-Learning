import pandas as pd
from utils import clean_data as clean
import matplotlib.pyplot as plt

df = pd.read_csv("train.csv")
clean(df)

print(df.Age.describe())


plt.boxplot(df.Age)
plt.title("Age distribution")
plt.ylabel("Age")

plt.show()

import pandas as pd
import matplotlib.pyplot as plt # to see the plots do not forget to uncomment the corresponding code
import numpy as np

# housing_data = np.genfromtxt('housing.csv', delimiter=',', dtype=None)
housing_data = pd.read_csv('housing.csv') # this returns a DataFrame()

col_name = ['longitude', 'latitude', 'housing_median_age', 'total_rooms', 'population', 'households', 'median_income', 'median_house_value']


for name in col_name:
    print('min for column <%s>: %s' % (name, housing_data[name].min()))
    print('index of min for column <%s>: %s' % (name, housing_data[name].idxmin())) # print the index of the min value

    print('max for column <%s>: %s' % (name, housing_data[name].max()))
    print('index of max for column <%s>: %s' % (name, housing_data[name].idxmax())) # print the index of the max value

    print('mean for column <%s>: %s' % (name, housing_data[name].mean()))

    print("---------------------------------------------------------------")

# uncomment below to plot...
'''
    plt.hist(housing_data[name])
    plt.title(name)
    plt.show()

'''

def split_data(df, train_percent=0.8):
    np.random.seed(1000000)
    permutation = df.reindex(np.random.permutation(df.index)) # use reindex and create a new frame with the same data but different index
    cut_point = int(train_percent * len(df))
    train = permutation[:cut_point]
    test = permutation[cut_point:]
    return train, test

train, test = split_data(housing_data)

# For checking correctness:
'''
print("train data=", train)
print(len(train))
print("test data", test)
print(len(test))
print(len(train)/len(test))
'''

for name in col_name:
    print('min for column <%s>: %s in train vs %s in test' % (name, train[name].min(), test[name].min()))
    print('index of min for column <%s>: %s vs %s in test' % (name, train[name].argmin(), test[name].argmin())) # print the index of the min value

    print('max for column <%s>: %s vs %s in test' % (name, train[name].max(), test[name].max()))
    print('index of max for column <%s>: %s vs %s in test' % (name, train[name].argmax(), test[name].argmax())) # print the index of the max value

    print('mean for column <%s>: %s vs %s in test' % (name, train[name].mean(), test[name].mean()))

    print("---------------------------------------------------------------")

# The test and the train sets have fairly similar means, not so similar but close min and max values and obviously very different index values

plt.scatter(housing_data['latitude'], housing_data['longitude'], c=housing_data["median_house_value"])
plt.colorbar()
plt.xlabel("Latitude")
plt.ylabel("Longitude")
plt.title("Location vs house value dependency")
plt.show()
import numpy as np

def create_hilbert_mat(s):
    a = np.zeros(shape=(s, s)) # Create a matrix of shape m rows by n columns

    for i in range(s):
        for j in range(s):
            a[i, j] = 1.0 / float(i+j+1)

    return a

H4by4 = create_hilbert_mat(4)
print(H4by4)

print(np.linalg.matrix_rank(H4by4)) # this prints 4
print(np.linalg.matrix_rank(create_hilbert_mat(100))) # this prints 18

for i in [1,2,3,5,10,15,20,30,50,100]:
    H = create_hilbert_mat(i)
    b = np.ones(i)
    x = np.linalg.solve(H,b)
    check = H.dot(x)-b
    print("x=", x)
    print("check=", check)
    print("-------------------------------------------------------------------")

# I do trust the solutions because the errors are very small as it can be seen by the terms in the printed check matrices:
# they are not perfectly zero because of the way floating point numbers are represented internally, but they are very close to zero.



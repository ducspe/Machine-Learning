import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV, KFold, cross_val_score, validation_curve
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error


df = pd.read_csv("housing.csv", delimiter=",")

x = df[["longitude", "latitude"]] # for simplicity take only the geographical location as the input to predict price
y = df["median_house_value"] # we want to predict the price

x_train, x_test, y_train, y_test = train_test_split(x, y, random_state = 0) # split the data in the train and test sets

# KNN Regression
parameters = {'n_neighbors':[5,10,15,20,25,30]}
knn = KNeighborsRegressor()
grid_obj = GridSearchCV(knn, parameters, cv=10, scoring='r2') # R^2 means the "Coefficient of Determination" which is a standard regression score function
grid_obj.fit(x,y) # Try to find a best fitting function approximator to our data

print("best_index", grid_obj.best_index_)
print("best_score", grid_obj.best_score_)
print("best_params", grid_obj.best_params_)
print(pd.DataFrame(grid_obj.cv_results_))

param_range = tuple(list(range(1, 20)))
train_scores, test_scores = validation_curve(KNeighborsRegressor(), x, y, param_name="n_neighbors", param_range=param_range,cv=10)
# cv = 10 => we use 10-fold cross-validation, see also: https://www.openml.org/a/estimation-procedures/1
test_scores_mean = np.mean(test_scores, axis=1)

plt.title("Validation Curve with KNN")
plt.xlabel("KNN")
plt.ylabel("Score")
plt.plot(param_range, test_scores_mean, label="Test score",)
plt.legend(loc="best")
plt.show()


########################

# KNN Regression with the optimal n (n_neighbors = 30)

knn = KNeighborsRegressor(n_neighbors=30)
knn.fit(x_train, y_train)
predicted_knn = knn.predict(x_test)

plt.scatter(y_test, predicted_knn)
plt.plot([-2,6], [-2, 6], "g--", lw=1, alpha=0.4)

plt.xlabel("True prices")
plt.ylabel("Predicted prices")
plt.text(0, 1, ' R-squared = {}'.format(round(float(knn.score(x_test,y_test)), 2)))
plt.text(0, 0.5, ' MSE = {}'.format(round(float(mean_squared_error(y_test, predicted_knn)), 2)))
plt.title('KNN (30) : Predicted prices vs. True prices')

plt.show()

# 10 folds cross-validation along the previous KNN regression

knn = KNeighborsRegressor(n_neighbors=30)
shuffle = KFold(n_splits=10, shuffle=True, random_state=0) # 10-fold because there are 10 splits of the data that get "rotated" in being the test vs validation sets
cv_scores = cross_val_score(knn, x, y, cv=shuffle)
print(cv_scores) # print the scores of each individual experiment
print(cv_scores.mean()) # the scores from the 10 experiments are averaged into one single score

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline


## Part a: ###
twenty_train = fetch_20newsgroups( categories=['alt.atheism', 'comp.graphics', 'sci.med', 'soc.religion.christian'], shuffle=True, random_state=41 )
twenty_test = fetch_20newsgroups( categories=['alt.atheism', 'comp.graphics', 'sci.med', 'soc.religion.christian'], shuffle=True, random_state=41 )

print(twenty_train.data)
print(twenty_train.filenames)
print(twenty_train.target[0])
print(twenty_train.target_names[twenty_train.target[0]])

## Part b: ###
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(twenty_train.data)
print(X_train_counts.shape)

print("Index of word 'image': ", count_vect.vocabulary_.get(u'image'))
print("All features: ", count_vect.get_feature_names())
print("Number of words: ", len(count_vect.get_feature_names()))
print(count_vect.get_feature_names().index('image')) # Alternative way to find index of a feature word
print("Find word by index: ", count_vect.get_feature_names()[17356])

## Part c: ###

clf = MultinomialNB().fit(X_train_counts, twenty_train.target)

docs_new = ['Some say Jesus was just an ordinary man','Satan is evil', 'the well known acronym stands for: graphical processing unit', 'images']
X_new_counts = count_vect.transform(docs_new)
predicted = clf.predict(X_new_counts)
print("Accuracy: ", clf.score(X_train_counts, twenty_train.target))

for doc, category in zip(docs_new, predicted):
    print('%r => %s' % (doc, twenty_train.target_names[category]))

text_clf = Pipeline([('vect', CountVectorizer()),
                     ('tfidf', TfidfTransformer()),
                     ('clf', MultinomialNB())
                     ])

clf2 = text_clf.fit(twenty_train.data, twenty_train.target)

print(clf2)

## Part d: ###

count_vect_st = CountVectorizer(stop_words='english')
X_train_counts_st = count_vect.fit_transform(twenty_train.data)
print(X_train_counts_st.shape) # slightly less words than in the previous case because the stop words are removed

clf = MultinomialNB().fit(X_train_counts_st, twenty_train.target)
docs_new = ['Some say Jesus was just an ordinary man','Satan is evil', 'the well known acronym stands for: graphical processing unit', 'images']
X_new_counts = count_vect.transform(docs_new)
predicted = clf.predict(X_new_counts)

print("Accuracy after removing stop words: ", clf.score(X_train_counts_st, twenty_train.target)) # train score is the same as previously...

# ## Part e: ###
# " Occurrence count is a good start but there is an issue: longer documents will have higher average count values than shorter documents, even
# though they might talk about the same topics. "
# " To avoid these potential discrepancies it suffices to divide the number of occurrences of each word in a document by the total number of
# words in the document: these new features are called tf for Term Frequencies. "